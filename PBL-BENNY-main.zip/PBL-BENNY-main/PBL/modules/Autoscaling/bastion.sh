# bastion userdata
#!/bin/bash
yum install -y mysql
yum install -y git tmux
yum install -y ansible